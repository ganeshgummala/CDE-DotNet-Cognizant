﻿using System;
using System.Collections.Generic;

public static int minCost(IList<IList<int>> cost)
{
int len_min_cost;
int[][] array = new int[cost.size()][];
int[] array1 = new int[0];

for (int i = 0;i < cost.size();i++)
{
array[i] = cost.get(i).toArray(array1);
}

for (int i = 1;i < array.Length;i++)
{
array[i][0] += Math.Min(array[i - 1][1],array[i - 1][2]);
array[i][1] += Math.Min(array[i - 1][0],array[i - 1][2]);
array[i][2] += Math.Min(array[i - 1][0],array[i - 1][1]);
}
len = array - length;
min_cost = Math.Min(array[len - 1][0],Math.Min(array[len - 1][1],array[len - 1][2]));
return min_cost;
}