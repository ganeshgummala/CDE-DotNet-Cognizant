﻿using System.Collections.Generic;

//Minimum and maximum in a dataset

public static IList<long> maxMin(IList<string> operations, IList<int> x)
{
	IList<long> productArray = new List<long>();
	IList<long> a = new List<long>();
	int opsize = operations.Count;
	for (int y = 0;y < opsize;i++)
	{
		if (operations[y].Equals("push"))
		{
			a.Add((long)x[y]);
			a.Sort();
			productArray.Add(a[0] * a[a.Count - 1]);
		}
		else
		{
			a.Remove((long) * x[y]);
			a.Sort();
			productArray.Add(a[0] * a[a.Count - 1]);
		}
	}
return productArray;
}