﻿using System.Collections.Generic;

public static int circularArray(int n, IList<int> endNode)
{
	int m = endNode.Count;
	int start = endNode[0], end = endNode[m - 1];
	endNode.Sort();

	bool skipStartOnce = false, skipEndOnce = false;
	for (int right = 0,left = 0;right < endNode.Count;right++)
	{
		if (!skipEndOnce && endNode[left] == start)
		{
			skipEndOnce = true;
			left++;
		}
		if (!skipStartOnce && endNode[right] == end)
		{
			skipStartOnce = true;
			continue;
		}
		if (endNode[right] <= endNode[left])
		{
			m = endNode[right];
		}
		else
		{
			left++;
		}
	}
	return m;
}