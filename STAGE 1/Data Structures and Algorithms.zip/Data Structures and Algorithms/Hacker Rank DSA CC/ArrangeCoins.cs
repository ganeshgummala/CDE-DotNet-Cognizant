public static void arrangeCoins(List<long> coins)
{
	for(int i=0;i<coins.Count;i++)
	{
		int count=0,j=1;
		while(coins[i]>=0)
		{
			coins[i] -= j;
			count++;
			j++;
		}
		Console.WriteLine(count-1);
	}
}