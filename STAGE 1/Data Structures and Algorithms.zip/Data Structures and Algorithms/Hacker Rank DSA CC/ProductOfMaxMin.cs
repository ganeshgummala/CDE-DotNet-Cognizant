﻿using System.Collections.Generic;

public static IList<long> maxMin(IList<string> operations, IList<int> x)
{
	IList<long> productArray = new List<long>();
	IList<long> a = new List<long>();
	int opsize = operations.Count;
	for (int y = 0;y < opsize;i++)
	{
		if (operations[y].Equals("push"))
		{
			a.Add((long)x[y]);
			a.Sort();
			productArray.Add(a[0] * a[a.Count - 1]);
		}
		else
		{
			a.RemoveAt((long)x[y]);
			a.Sort();
			productArray.Add(a[0] * a[a.Count - 1]);
		}
	}
return productArray;
}