﻿using System.Collections.Generic;

// Array Game

 public static long countMoves(IList<int> numbers)
 {
// Write your code here 
	long arrsum, smallest, arr_size = numbers.Count;
	arrsum = 0;
	smallest = (long)numbers[0];
	for (int i = 0; i < arr_size; i++)
	{
		long temp = (long)numbers[i];
		if (temp < smallest)
		{
			smallest = temp;
		}
	   arrsum += temp;
	}
	long minoperation = arrsum - arr_size * smallest;
	return minoperation;
 }