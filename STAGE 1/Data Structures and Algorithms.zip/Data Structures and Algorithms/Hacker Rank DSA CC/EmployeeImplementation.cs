﻿using System;
using System.Collections.Generic;

internal interface Company
{

void assignsalaries(int[] salaries);
void averageSalary();
void maxSalary();
void minsalary();

}

internal class AccountFirm : EngineerFirm
{
public virtual AccountantFirm(int n)
{
base(n);
}
public override void assignSalaries(int[] salaries)
{
base.assignIncome(salaries);
printMessages(0,"","accountants");
}

public override void maxSalary()
{
printMessages(base.MaxSalary(),"max","accountants");
}

public override void minSalary()
{
printMessages(base.MinSalary(),"min","accountants");
}

public override void averageSalary()
{
printMessages(base.AveSalary(),"ave","accountants");
}
}

internal class EngineerFirm
{
private readonly int[] income;

public EngineerFirm(int n)
{
income = new int[n];
for (int i = 0;i < n;i++)
{
income[i] = 0;
}
}

public static void printMessages(double salaryAmount, string salarySpecification, string profession)
{
switch (salarySpecification)
{
case "max":
	Console.Write("Maximum salary amongst" + profession);
Console.Write("is {0:D}",(int)salaryAmount);
Console.WriteLine("");
break;

case "min":
Console.Write("Minimum salary amongst" + profession);
Console.Write("is {0:F2}",salaryAmount);
Console.WriteLine("");
break;
default:
Console.WriteLine("Incomes of" + profession + "credited");
break;
}
}

public virtual void assignSalaries(int[] salaries)
{
if (salaries != null)
{
assignIncome(salaries);
printMessages(0,"","engineers");
}
}

public virtual void maxSalary()
{
printMessages(MaxSalary(),"max","engineers");
}

public virtual void minSalary()
{
printMessages(MinSalary(),"min","engineers");
}

public virtual void averageSalary()
{
printMessages(AveSalary(),"ave","engineers");
}
}

public virtual int? MaxSalary()
{
IList<int> list = java.util.Arrays.stream(income).boxed().collect(Collectors.toList());
return list.Max(int.compare).get();
}

public virtual int? MinSalary()
{
IList<int> list = java.util.Arrays.stream(income).boxed().collect(Collectors.toList());
return list.Min(int.compare).get();
}

public virtual int? AveSalary()
{
IList<int> list = java.util.Arrays.stream(income).boxed().collect(Collectors.toList());

IntSummaryStatistics stats = list.stram().mapToInt((x) => x).summaryStatistics();
return stats.getAverage();
}

public virtual void assignIncome(int[] salaries)
{
Array.Copy(salaries,0,income,0,Math.Min(income.length,salaries.Length));
}
}

public class Solution
{
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in C#:
//ORIGINAL LINE: public static void main(String args[])throws Exception
public static void Main(string[] args)
{
Scanner sc = new Scanner(System.in);
string[] count = sc.nextLine().Split("");
EngineerFirm e = new EngineerFirm(int.Parse(count[0]));
AccountantFirm(int.Parse(count[1]));
count = sc.nextLine().Split("");
int[] incomeEngineers
}
}