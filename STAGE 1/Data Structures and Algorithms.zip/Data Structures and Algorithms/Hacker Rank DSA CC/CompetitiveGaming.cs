﻿using System.Collections.Generic;

public static int numPlayers(int k, IList<int> scores)
{
	scores.Sort(Collections.reverseOrder());
	int rank = 1;
	int res = 0;
	for (int i = 0;i < scores.Count;i++)
	{
		if (i == 0)
		{
			rank = 1;
		}
		else if (scores[i] != scores[i - 1])
		{
			rank = i + 1;
		}
		if (rank <= k && scores[i]>0)
		{
			res++;
		}
		else
		{
			break;
		}
	}
return res;
}