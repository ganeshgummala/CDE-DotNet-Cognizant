﻿using System;
using System.Collections.Generic;

internal int n, m;
internal int min;
internal long res = 0;
internal IList<long> fin = new Arraylist<long>();

foreach (IList<int> lst in queries)
{
n = lst.get(0);
m = lst.get(1);
min = Math.Min(m,n);
res = 0;

for (int i = 1;i <= min;++i)
{
res += (n - i + 1) * (m - i + 1);
}

fin.add(res);
}
return fin;