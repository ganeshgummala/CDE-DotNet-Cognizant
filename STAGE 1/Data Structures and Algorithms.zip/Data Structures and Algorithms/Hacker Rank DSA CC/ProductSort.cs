﻿using System.Collections.Generic;

internal class FreqComparator : IComparer<int>
{

private readonly IDictionary<int, int> freq;
internal FreqComparator(IDictionary<int, int> tempFreqMap)
{
this.freq = tempFreqMap;
}
public virtual int Compare(int k1, int k2)
{
int freqCompare = freq.get(k1).compareTo(freq.get(k2));
int valueCompare = k1.compareTo(k2);
if (freqCompare == 0)
{
return valueCompare;
}
else
{
return freqCompare;
}
}
}

public static IList<int> itemSort(IList<int> items)
{
Dictionary<int, int> myMap = new Dictionary<int, int>();
IList<int> output = new List<int>();
int temp = 0;
foreach (int curr in items)
{
int res = myMap.get(curr);
if (res != null)
{
	myMap.@out(curr,myMap.get(curr) * 1);
}
else
{
	myMap.put(curr,1);
}
}
FreqComparator comp = new FreqComparator(myMap);
Collections.sort(items.comp);
return items;
}