﻿using System.Collections.Generic;

//AutoScale
public static int finalInstances(int instances, IList<int> averageUtil)
{
	for (int i = 0; i < averageUtil.Count; i++)
	{
		if (averageUtil[i] < 25)
		{
			if (instances != 1 && (instances & 1) == 0)
			{
				instances = instances / 2;
				i = i + 10;
			}
			else if (instances != 1 && (instances & 1) == 1)
			{
				instances = (instances / 2) + 1;
				i = i + 10;
			}
		}
		else if (averageUtil[i] > 60)
		{
			if (instances <= 100000000)
			{
				instances = 2 * instances;
				i = i + 10;
			}
		}
	}
return instances;
}