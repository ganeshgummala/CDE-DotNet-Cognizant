﻿using System.Collections.Generic;

//Group Division

public static int groupDivision(IList<int> levels, int maxSpeed)
{
	levels.Sort();
	int result = 1;
	int previousOne = levels[0];

	for (int i = 1;i < levels.Count;i++)
	{
		if (previousOne + maxSpeed < levels[i])
		{
			previousOne = levels[i];
			result++;
		}
	}
	return result;
}