﻿using System;

//Count no of ways to divide n in k group

internal class main
{
	internal static int calculate(int pos, int prev, int left, int k)
	{
		if (pos == k)
		{
			if (left == 0)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		if (left == 0)
		{
			return 0;
		}
		int answer = 0;
		for (int i = prev;i <= left;i++)
		{
			answer += calculate(pos + 1,i,left - i,k);
		}
		return answer;

	}
	internal static int countWaysToDivide(int n, int k)
	{
		return calculate(0,1,n,k);
	}
//JAVA TO C# CONVERTER NOTE: Members cannot have the same name as their enclosing type:
	public static void Main(@string[] args)
	{
		int N = 8, K = 4;
		Console.WriteLine(countWaysToDivide(N,K));
	}
}