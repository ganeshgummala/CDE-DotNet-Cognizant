﻿using System.Collections.Generic;

public static char slowestKey(IList<IList<int>> keyTimes)
{

//JAVA TO C# CONVERTER NOTE: The following call to the 'RectangularArrays' helper class reproduces the rectangular array initialization that is automatic in Java:
//ORIGINAL LINE: int[][] arr = new int[keyTimes.size()][2];
int[][] arr = RectangularArrays.RectangularIntArray(keyTimes.size(), 2);
//JAVA TO C# CONVERTER NOTE: The following call to the 'RectangularArrays' helper class reproduces the rectangular array initialization that is automatic in Java:
//ORIGINAL LINE: int[][] arr2 = new int[keyTimes.size()][2];
int[][] arr2 = RectangularArrays.RectangularIntArray(keyTimes.size(), 2);

for (int i = 0;i < keyTimes.size();i++)
{
IList<int> list = keyTimes.get(i);
for (int j = 0;j < 2;j++)
{
arr[i][j] = list.get(j);
arr2[i][j] = list.get(j);
}
}

int prev = 0;
for (int i = 0;i < keyTimes.size();i++)
{
arr2[i][1] = arr[i][1] - prev;
prev = arr[i][1];
}

int max = int.MinValue;
int ans = 0;
for (int i = 0;i < keyTimes.size();i++)
{
int value = arr2[i][1];
if (value > max)
{
ans = arr2[i][0];
max = arr2[i][1];
}
}
int result = 97 + ans;
char c = (char)result;
return c;
}