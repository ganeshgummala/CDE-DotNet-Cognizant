﻿using System.Collections.Generic;

public static int getMinimumMoves(IList<int> arr)
{
int count = 1, n = arr.size();
int min = arr.get(n - 1);
int last = min;
IList<int> sorted = new List<int>();
sorted.add(min);
for (int i = n - 2;i >= 0;i--)
{
int temp = arr.get(i);
if (temp <= min)
{
count++;
sorted.add(temp);
min = temp;
}
else if (temp < last)
{
while (sorted.get(0) > temp)
{
sorted.remove(0);
count--;
}
last = sorted.get(0);
}
}
}