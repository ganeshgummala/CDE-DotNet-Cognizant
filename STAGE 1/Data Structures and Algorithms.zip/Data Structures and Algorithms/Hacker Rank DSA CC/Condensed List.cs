﻿using System.Collections.Generic;

//Condensed list

public static SinglyLinkedListNode condense(SinglyLinkedListNode head)
{
	IList<int> nodesList = new IList<int>();
	SinglyLinkedListNode ptr1;
	SinglyLinkedListNode ptr2;

	ptr1 = head;
	ptr2 = null;

	while (ptr1 != null)
	{
		int val = ptr1.data;
		if (nodesList.Contains(val))
		{
			ptr2.next = ptr1.next;
		}
		else
		{
			nodesList.Add(val);
			ptr2 = ptr1;
		}
		ptr1 = ptr1.next;
	}
	return head;
}