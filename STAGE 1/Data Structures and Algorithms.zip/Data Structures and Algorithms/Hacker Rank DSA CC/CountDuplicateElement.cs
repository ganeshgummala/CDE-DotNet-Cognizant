﻿using System.Collections.Generic;

public static int countDuplicate(IList<int> numbers)
{
int[] arr = new int[numbers.size()];
for (int i = 0;i < numbers.size();i++)
{
arr[i] = numbers.get(i);
}

IList<int> li = new List<int>();
for (int i = 0;i < arr.Length;i++)
{
for (int j = i + 1;j < arr.Length;j++)
{
if (arr[i] == arr[j])
{

li.add(arr[i]);
}
}
}
IList<int> listwithout = new List<int>(new HashSet<>(li));
return listwithout.size();
}