﻿using System.Collections.Generic;

// Merge Two Arrays

public static IList<int> mergeArrays(IList<int> a, IList<int> b)
{
	IList<int> @out = new List<int>();
	((List<int>)@out).AddRange(a);
	((List<int>)@out).AddRange(b);
	@out.Sort(System.Collections.IComparer.naturalOrder());
	return @out;
}