﻿using System.Collections.Generic;

public static IList<int> getElements(IList<int> arr, IList<IList<int>> queries)
{
int s;
IList<integer> row = new arrayList<int>();
for (int i = 0;i < queries.size();i++)
{
s = ((queries.get(i).get(0) - 1) * arr.get(0)) + queries.get(i).get(1);
row.add(arr.get(s));
}
return (row);
}