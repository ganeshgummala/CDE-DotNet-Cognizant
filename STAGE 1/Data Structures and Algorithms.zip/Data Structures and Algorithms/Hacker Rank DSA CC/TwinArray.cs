﻿using System.Collections.Generic;

public static bool areTwins(string a, string b)
{
return get_even(a).Equals(get_even(b)) && get_odd(a).Equals(get_odd(b));
}

public static IDictionary<char, int> get_even(string s)
{
return get_f(s,0);
}

public static IDictionary<char, int> get_f(string s, int num)
{
IDictionary<char, int> x = new Dictionary<char, int>();
char[] str_array = s.ToCharArray();
for (int i = num;i < str_array.Length;i = i + 2)
{
char c = str_array[i];
if (x.containsKey(c))
{
	x.put(c,x.get(c) + 1);
}
else
{
	x.put(c,1);
}
}
return x;
}

public static IList<string> twins(IList<string> a, list<string> b)
{
IList<string> res = new List<string>();
for (int i = 0;i < a.size();i++)
{
if (aretwins(a.get(i),b.get(i)))
{
res.add("Yes");
}
else
{
res.add("No");
}
}
return res;
}