# Car rental system - add new column

Refer to the given schema. Assume, CARS table has been already created. Write an appropriate query for the given requirement.  
Requirement 1: Add a new column Car_Regno VARCHAR(10)  to the Cars table.

*Note: Letters in the bold represents the attribute name.*

![database diagram](../../../database_2.png)