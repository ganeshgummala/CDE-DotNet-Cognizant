# car rental system - Insert values


Refer to the given schema diagram. Insert the below records into Rentals Table. Assume the rentals table has been already created.

![data](data.png)

![database 4](../../../database_3.png)