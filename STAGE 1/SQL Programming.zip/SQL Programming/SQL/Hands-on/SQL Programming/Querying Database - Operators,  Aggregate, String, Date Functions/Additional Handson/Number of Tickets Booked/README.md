# Number of Tickets Booked

Write a query to display the user id and number of time tickets was booked by each user. Give an alias name as no_of_times. Sort the result based on the user_id.

> **Note:**
> Evaluate only the respective query to get the desired result.

![database diagram](../../../database_4.jpg)