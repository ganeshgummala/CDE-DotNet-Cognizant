# Hotels that took order more than five times

Write a query to display hotel id, hotel name, and number of orders taken by hotels that have taken orders more than 5 times. Give an alias name for number of orders as 'NO_OF_ORDERS'.sort the result based on hotel id in ascending order.

> (HINT: Use Hotel_details and Orders tables to retrieve records.)

*NOTE: Maintain the same sequence of column order, as specified in the question description*

![database demo](../../../database_3.png)