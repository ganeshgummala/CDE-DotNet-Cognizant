# Customer using HDFC bank

Write a query to display the unique user name and their city who have booked their tickets by not using the HDFC bank for any of the bookings. Sort the result based on the user name.

> **Note:** 
> Evaluate only the respective query to get the desired result. Data is case sensitive.

![database diagram](../../../database_4.jpg)

