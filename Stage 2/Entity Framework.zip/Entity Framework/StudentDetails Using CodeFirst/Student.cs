using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement   //DO NOT Change the namespace name
{
    public class Student     //DO NOT Change the class name
    {
       //Create the properties
       public int StudentId { get; set;}
       public string StudentName { get; set;}
       public DateTime EnrolledDate { get; set;}
       public string Department { get; set;}
       public long PhoneNumber { get; set;}
    }
}
