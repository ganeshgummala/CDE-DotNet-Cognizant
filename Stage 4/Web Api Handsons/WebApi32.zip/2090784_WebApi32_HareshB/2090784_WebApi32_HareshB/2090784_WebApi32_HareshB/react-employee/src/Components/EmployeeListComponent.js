import React,{useState,useEffect} from 'react';
import axios from 'axios';
import {Container,Row,Table} from 'react-bootstrap';
import EmployeeInsertComponent from './EmployeeInsertComponent';

function EmployeeListComponent()
{
    const[EmployeeList,setEmployeeList]=useState([])


    //Getting data from api using fetch() -- WORKING CODE
    // useEffect(() => {
    //     fetch("http://localhost:31300/api/Employee")
    //     .then(response => response.json())
    //     .then(json => {
    //       console.log(json);
    //       setEmployeeList(json);
    //   })
        
    // },[])
 
    //Getting data from api using Axios--WORKING CODE
    axios.get("http://localhost:31300/api/Employee").then((response)=>{
        setEmployeeList(response.data)
    })


//     fetch("http://localhost:31300/api/Employee").then(response => response.json())
//     .then(json => {
//       console.log(json);
//       setEmployeeList([json]);
//   })
    //  setPostArray([{name: 'a'}, {name: 'b'},{name: 'c'}])
  
        //setEmployeeList(response.data)
        //console.log(response.data);
    

    console.log(EmployeeList);


    // var EmployeeDetails=[]
    // EmployeeList.map((employee)=>{
    //     EmployeeDetails.push(<EmployeeInsertComponent id={employee.id} name={employee.name} location={employee.location} salary={employee.salary}/>)
    // })


    return(
        // <Container>
        //    <Row><h2>Employees List</h2></Row>
        //    <Row>
        //      {EmployeeDetails}
        //    </Row>
        // </Container>
         <div>
       
             <Row><h2>Employee Details</h2></Row>
             <Table>  
             <thead>
                 <tr>
                     <th>Employee Id</th>
                     <th>Employee Name</th>
                     <th>Location</th>
                    <th>Salary</th>
                </tr>
            </thead>
            <tbody>
             {EmployeeList.map((e)=>(
                
                <tr>
                    <td>{e.id}</td>
                    <td>{e.name}</td>
                    <td>{e.location}</td>
                    <td>{e.salary}</td>
                </tr>
               
             ))}
             </tbody>
            
            </Table>
       </div>

    // <div>
    //     <table>
    //         <thead>
    //             <tr>
    //                 <th>ID</th>
    //                 <th>Name</th>
    //                 <th>Location</th>
    //                 <th>Salary</th>
    //             </tr>
    //         </thead>
    //         {EmployeeList.map((emp)=>{
    //             <tbody>
    //                 <tr>
    //                     <td>{emp.Id}</td>
    //                     <td>{emp.Name}</td>
    //                     <td>{emp.Location}</td>
    //                     <td>{emp.Salary}</td>
    //                 </tr>
    //             </tbody>
    //         })}
    //     </table>
    // </div>
    )
}

export default EmployeeListComponent;