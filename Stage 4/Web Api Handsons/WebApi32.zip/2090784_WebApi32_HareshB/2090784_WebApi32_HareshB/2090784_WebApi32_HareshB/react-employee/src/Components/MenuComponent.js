import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import * as RB from 'react-bootstrap';

function MenuComponent()
{
    return(
        <RB.Navbar bg="dark" variant="dark">
            <RB.Navbar.Brand>Employee Details</RB.Navbar.Brand>
            <RB.Nav.Link href="/View" className="text-white">View Employee Details</RB.Nav.Link>
            <RB.Nav.Link href="/Insert" className="text-white">Insert Employee Details</RB.Nav.Link>
        </RB.Navbar>
    )
}

export default MenuComponent;