﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiSwagger.Controllers
{
    [Route("api/emp")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        List<Employee> employees = new List<Employee>()
        {
            new Employee(){Id=101,Name="Aman",Location="Chennai",Salary=50000},
            new Employee(){Id=102,Name="Haresh",Location="Pune",Salary=26000 },
            new Employee(){Id=103,Name="Arun",Location="Hydrabad",Salary=30000},
            new Employee(){Id=104,Name="Dean",Location="Kochi",Salary=80000}
        };

        [HttpGet]
        public IEnumerable<Employee> get()
        {
            return employees;
        }

    }
}
