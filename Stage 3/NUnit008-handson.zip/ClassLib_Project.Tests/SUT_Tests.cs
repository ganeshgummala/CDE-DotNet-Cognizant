﻿using CollectionsLib;
using NUnit.Framework;
using System;

namespace ClassLib_Project.Tests
{
    [TestFixture]
    public class SUT_Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void UnitUnderTest_Scenario_ExpectedOutcome_NOT_NULL()
        {
            var acc = new Adapter();
            if (acc.GetEmployees() == null)
            {
                Assert.Fail();
            }
            Assert.Pass();
        }

        [TestCase(100)]
        public void UnitUnderTest_Scenario_ExpectedOutcome_100_Exists(int id)
        {
            var acc = new Adapter();
            if (acc.GetEmpById(id)) 
                Assert.Pass();
            Assert.Fail();
        }

        [Test]
        public void UnitUnderTest_Scenario_ExpectedOutcome_UNIQUE_LIST()
        {
            var acc = new Adapter();
            if (acc.IsUnique()) 
                Assert.Pass();
            Assert.Fail();
        }

        [Test]
        public void UnitUnderTest_Scenario_ExpectedOutcome_GET_EMPLOYEES()
        {
            var acc = new Adapter();
            foreach (var e in acc.EmployeeList)
            {
                if (e.ID == 100 || e.ID == 200 || e.ID == 400 || e.ID == 600)
                {
                    Assert.Pass();
                }
            }
            Assert.Fail();
        }

        [Test]
        public void UnitUnderTest_Scenario_ExpectedOutcome_GetEmployeesWhoJoinedInPreviousYears()
        {
            var acc = new Adapter();
            var list = acc.GetEmployeesWhoJoinedInPreviousYears(2000);
            foreach (var e in list)
            {
                if (e.ID == 100)
                {
                    Assert.Pass();
                }  
            }
            Assert.Fail();
        }
    }
}
