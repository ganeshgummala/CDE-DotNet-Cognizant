﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsLib
{
    public class Employee
    {
        public int ID { get; set; }
        public string NAME { get; set; }
        public DateTime DATE_OF_JOINING { get; set; }
        public double SALARY { get; set; }

        public Employee(int id, string name, DateTime doj, double salary) 
        {
            this.ID = id;
            this.NAME = name;
            this.DATE_OF_JOINING = doj;
            this.SALARY = salary;
        }

        public override bool Equals(Object obj) 
        {
            bool flag = false;
            Employee emp = obj as Employee;
            if (emp.ID == this.ID) 
            {
                flag = true;
            }
            return flag;
        }

        public override int GetHashCode() 
        {
            int f = 0;
            
            return f;
        }
    }
}
