﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsLib
{
    public class Adapter
    {
        public List<Employee> EmployeeList = new List<Employee>() { 
            new Employee(100, "Rahul", DateTime.Parse("10/10/2000"), 50000),
            new Employee(200, "Ranjan", DateTime.Parse("10/10/2002"), 60000),
            new Employee(400, "Sparrow", DateTime.Parse("10/10/2004"), 80000),
            new Employee(600, "Ranjan", DateTime.Parse("10/10/2006"), 40000)
        };

        public List<Employee> GetEmployees() 
        {
            List<Employee> emplist = EmployeeList;
            return emplist;
        }
        public List<Employee> GetEmployeesWhoJoinedInPreviousYears(int year) 
        {
            List<Employee> emplist = EmployeeList.Where(x => x.DATE_OF_JOINING.Year == year).ToList();
            return emplist;
        }
        public bool GetEmpById(int id) 
        { 
            var c = EmployeeList.Where(x => x.ID == id).Count();
            if(c > 0) return true;
            else return false;
        }
        public bool IsUnique() 
        { 
            var flag = false;
            int count = 0;
            foreach(var e in EmployeeList) 
            { 
                var list = EmployeeList.Where(x => x.ID == e.ID).Count();
                if(list == 1) count++;
            }
            if(count == EmployeeList.Count) flag = true;
            return flag;
        }
    }
}
