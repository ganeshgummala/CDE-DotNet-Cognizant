﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncAwait
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            Method1();
            Console.ReadKey();
        }
        public static async void Method1()
        {
            Task<string> task = Method2();
            string method2String = await task;
            Console.WriteLine(method2String);
        } 
        public static async Task<string> Method2()
        {
            await Task.Run(()=> Thread.Sleep(1000));
            return "String return by method2";
        }
    }
}
