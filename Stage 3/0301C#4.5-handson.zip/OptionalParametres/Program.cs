﻿using System;

namespace OptionalParametres
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            OrderDetails("Rahim Mobile Stores","Samsung Galaxy s21",2,false);
            OrderDetails("Rahim Mobile Stores", "Samsung Galaxy s21");
            Console.ReadKey();
        }
        public static void OrderDetails(string sellerName,string productName,int orderQuantity=1,bool isReturnable=true)
        {
            Console.WriteLine("Here is the order detail" +
                " – {0} number of {1}" +
                " by {2} is ordered." +
                " It’s returnable status is {3}",orderQuantity,productName,sellerName,isReturnable);
        }
    }
}
