﻿using System;

namespace NamedParametres
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            GetCohortDetails(gencCount:45,mode:"online",cohortName:"CDE21ID008",track:".Net",currentModule:"Asp .net MVC");
            Console.ReadKey();
        }
        public static void GetCohortDetails(string cohortName,int gencCount,string mode,string track,string currentModule)
        {
            Console.WriteLine("It is {0} with {1} GenCs" +
                " undergoing training for {2} thru {3}." +
                " The current module of training is {4}"
                ,cohortName,gencCount,mode,track,currentModule);
        }
    }
}
