﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsyncAndAwaitWFA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private int countCharacters()
        {
            int count = 0;

            using(StreamReader reader = new StreamReader("c:\\dataSample\\words.txt"))
            {
                string content = reader.ReadToEnd();
                count = content.Length;
                Thread.Sleep(5000);
            }
            return count;
        }

        private async void btnCalculate_Click(object sender, EventArgs e)
        {
            Task<int> task = new Task<int>(countCharacters);
            task.Start();
            lblCount.Text = "Counting characters...Please wait.";
            int count = await task;
            lblCount.Text = "Total number of characters = " + count.ToString();
        }
    }
}
