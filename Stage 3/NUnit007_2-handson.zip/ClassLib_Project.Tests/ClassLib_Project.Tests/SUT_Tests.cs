using NUnit.Framework;
using AccountsManagerLib;

namespace ClassLib_Project.Tests
{
    public class SUT_Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void UnitUnderTest_Scenario_ExpectedOutcome()
        {
            var acc = new AccountsManager();
            string result = acc.Validate("user_11", "secret@user11");
            string expected = "Welcome user_11 !!!";
            Assert.That(expected, Is.EqualTo(result));
        }

        [Test]
        public void UnitUnderTest_Scenario_ExpectedOutcome_2() 
        {
            var acc = new AccountsManager();
            string result = acc.Validate("user", "secret@user");
            string expected = "Invalid user id/password";
            Assert.That(expected, Is.EqualTo(result));
        }
    }
}