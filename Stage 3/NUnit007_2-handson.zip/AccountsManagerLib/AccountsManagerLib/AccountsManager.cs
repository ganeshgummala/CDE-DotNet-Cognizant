﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountsManagerLib
{
    public class AccountsManager
    {
        public string Validate(string UserId, string Password) 
        {
            string text = "";
            if (
                (UserId.Equals("user_11") && Password.Equals("secret@user11"))
                || (UserId.Equals("user_22") && Password.Equals("secret@user22"))
                )
            {
                text = "Welcome " + UserId + " !!!";
            }
            else 
            {
                text = "Invalid user id/password";
            }
            return text;
        }
    }
}
