﻿
namespace BasicCalculatorFormApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.radioAddButton1 = new System.Windows.Forms.RadioButton();
            this.radioSubButton2 = new System.Windows.Forms.RadioButton();
            this.radioMulButton3 = new System.Windows.Forms.RadioButton();
            this.radioDivButton4 = new System.Windows.Forms.RadioButton();
            this.calculateButton1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(209, 69);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(150, 31);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "Number1";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(432, 69);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(150, 31);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "Number2";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // radioAddButton1
            // 
            this.radioAddButton1.AutoSize = true;
            this.radioAddButton1.Location = new System.Drawing.Point(209, 162);
            this.radioAddButton1.Name = "radioAddButton1";
            this.radioAddButton1.Size = new System.Drawing.Size(106, 29);
            this.radioAddButton1.TabIndex = 2;
            this.radioAddButton1.TabStop = true;
            this.radioAddButton1.Text = "Addition";
            this.radioAddButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioAddButton1.UseVisualStyleBackColor = true;
            // 
            // radioSubButton2
            // 
            this.radioSubButton2.AutoSize = true;
            this.radioSubButton2.Location = new System.Drawing.Point(432, 162);
            this.radioSubButton2.Name = "radioSubButton2";
            this.radioSubButton2.Size = new System.Drawing.Size(128, 29);
            this.radioSubButton2.TabIndex = 3;
            this.radioSubButton2.TabStop = true;
            this.radioSubButton2.Text = "Subtraction";
            this.radioSubButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioSubButton2.UseVisualStyleBackColor = true;
            // 
            // radioMulButton3
            // 
            this.radioMulButton3.AutoSize = true;
            this.radioMulButton3.Location = new System.Drawing.Point(209, 220);
            this.radioMulButton3.Name = "radioMulButton3";
            this.radioMulButton3.Size = new System.Drawing.Size(144, 29);
            this.radioMulButton3.TabIndex = 4;
            this.radioMulButton3.TabStop = true;
            this.radioMulButton3.Text = "Multiplication";
            this.radioMulButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioMulButton3.UseVisualStyleBackColor = true;
            // 
            // radioDivButton4
            // 
            this.radioDivButton4.AutoSize = true;
            this.radioDivButton4.Location = new System.Drawing.Point(432, 220);
            this.radioDivButton4.Name = "radioDivButton4";
            this.radioDivButton4.Size = new System.Drawing.Size(100, 29);
            this.radioDivButton4.TabIndex = 5;
            this.radioDivButton4.TabStop = true;
            this.radioDivButton4.Text = "Division";
            this.radioDivButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioDivButton4.UseVisualStyleBackColor = true;
            // 
            // calculateButton1
            // 
            this.calculateButton1.Location = new System.Drawing.Point(335, 284);
            this.calculateButton1.Name = "calculateButton1";
            this.calculateButton1.Size = new System.Drawing.Size(112, 34);
            this.calculateButton1.TabIndex = 6;
            this.calculateButton1.Text = "Calculate";
            this.calculateButton1.UseVisualStyleBackColor = true;
            this.calculateButton1.Click += new System.EventHandler(this.calculateButton1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.calculateButton1);
            this.Controls.Add(this.radioDivButton4);
            this.Controls.Add(this.radioMulButton3);
            this.Controls.Add(this.radioSubButton2);
            this.Controls.Add(this.radioAddButton1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.RadioButton radioAddButton1;
        private System.Windows.Forms.RadioButton radioSubButton2;
        private System.Windows.Forms.RadioButton radioMulButton3;
        private System.Windows.Forms.RadioButton radioDivButton4;
        private System.Windows.Forms.Button calculateButton1;
    }
}

