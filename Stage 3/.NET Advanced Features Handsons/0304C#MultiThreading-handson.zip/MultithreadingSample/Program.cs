﻿using System;
using System.Threading;

namespace MultithreadingSample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*****Multithreading program*****\n");
            Console.WriteLine("Main thread started. ThreadId={0}", Thread.CurrentThread.ManagedThreadId);

            Printer p = new Printer();

            WaitCallback workItem = new WaitCallback(PrintTheNumbers);

            for(int i = 0; i < 10; i++)
            {
                ThreadPool.QueueUserWorkItem(workItem, p);
            }

            Console.WriteLine("All tasks queued");
            Console.ReadKey();
            //Console.WriteLine("Hello World!");
        }
        static void PrintTheNumbers(object state)
        {
            Printer task = (Printer)state;
            task.PrintNumbers();
        }
    }
}
