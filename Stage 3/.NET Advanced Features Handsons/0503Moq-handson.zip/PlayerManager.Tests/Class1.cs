﻿using NUnit.Framework;
using PlayersManagerLib;
using System;
using Moq;

namespace PlayerManager.Tests
{
    [TestFixture]
    public class Class1
    {
        [Test]
       
        public void testPlayerMapper()
        {
            Mock<PlayerMapper> mock = new Mock<PlayerMapper>();
            mock.Setup(x => x.IsPlayerNameExistsInDb("Virat")).Returns(false);
            Assert.AreEqual(false, mock.Object.IsPlayerNameExistsInDb("Virat"));
        }
    }
}
