﻿using CustomerCommLib;
using Moq;
using NUnit.Framework;
using System;

namespace CustomerComm.Tests
{
    [TestFixture]
    public class Class1
    {
        [Test]
        public void checkByMock()
        {
            Mock<MailSender> mock= new Mock<MailSender>();
            mock.Setup(x => x.SendMail("abc@gmail.com","Hi hello")).Returns(true);
            Assert.AreEqual(true, mock.Object.SendMail("abc@gmail.com", "Hi hello"));
        }
    }
}
