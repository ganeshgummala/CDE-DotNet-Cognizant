﻿using MagicFilesLib;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace DirectoryExplorer.Tests
{
    [TestFixture]
    public class Class1
    {
        private readonly string _file1 = "file.txt";
        private readonly string _file2 = "file2.txt";

        [Test]
        public void testByMockFile()
        {
            Mock<IDirectoryExplorer> mock = new Mock<IDirectoryExplorer>();
            mock.Setup(x => x.GetFiles(_file1));
            Assert.Contains(_file1, (System.Collections.ICollection)mock.Object.GetFiles("file.txt"));
            Assert.IsNotNull(mock);
        }
    }
}
