﻿using NUnit.Framework;
using System;

namespace CalculatorLib.Tests
{
    [TestFixture]
    public class CalculatorTest
    {
        [TestCase]
        public void Add_When_Both_Inputs_GreaterThanZero_Returns_ExpectedResult()
        {
            //Arrange
            Calculator calculator = new Calculator();

            int firstNo = 30;
            int secondNo = 20;

            int expectedResult = 50;

            int actualResult;
            actualResult = calculator.Add(firstNo, secondNo);

            //Assert

            Assert.That(expectedResult == actualResult, "Verify the add method logic");
        }
        [TestCase]
        public void Add_When_input1GrThanZero_input2LsThanZero_Returns_ExpectedResult()
        {
            //Arrange
            Calculator calculator = new Calculator();

            int firstNo = 30;
            int secondNo = -2;

            int expectedResult = -1;

            int actualResult;
            actualResult = calculator.Add(firstNo, secondNo);

            //Assert

            Assert.That(expectedResult == actualResult, "Verify the add method logic");
        }
        [TestCase]
        public void Add_When_input1LsThanZero_input2GrThanZero_Returns_ExpectedResult()
        {
            //Arrange
            Calculator calculator = new Calculator();

            int firstNo = -3;
            int secondNo = 20;

            int expectedResult = -2;

            int actualResult;
            actualResult = calculator.Add(firstNo, secondNo);

            //Assert

            Assert.That(expectedResult == actualResult, "Verify the add method logic");
        }
        [TestCase]
        public void Add_When_Both_Inputs_LessThanZero_Returns_ExpectedResult()
        {
            //Arrange
            Calculator calculator = new Calculator();

            int firstNo = -3;
            int secondNo = -2;

            int expectedResult = 0;

            int actualResult;
            actualResult = calculator.Add(firstNo, secondNo);

            //Assert

            Assert.That(expectedResult == actualResult, "Verify the add method logic");
        }

    }
}
