﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeapYearCalculatorLib
{
    public class LeapYear
    {
        public int IsLeap(int year) 
        {
            int flag = 0;
            if (year >= 1753 && year <= 9999)
            {
                if (year % 4 == 0) 
                {
                    if (year % 100 == 0) 
                    { 
                        if(year % 400 == 0) flag = 1;
                        else flag = 0;
                    }
                    else 
                    { 
                        flag = 1;
                    }
                }
                else 
                { 
                    flag = 0;
                }
            }
            else flag = -1;
            return flag;
        }
    }
}
