using NUnit.Framework;
using LeapYearCalculatorLib;

namespace ClassLib_Project.Tests
{
    public class SUT_Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [TestCase(2000, 1)]
        [TestCase(2009, 0)]
        [TestCase(2012, 1)]
        [TestCase(00005, -1)]
        public void UnitUnderTest_Scenario_ExpectedOutcome(int year, int expected)
        {
            var leap = new LeapYear();
            int result = leap.IsLeap(year);
            Assert.That(expected, Is.EqualTo(result));
        }
    }
}