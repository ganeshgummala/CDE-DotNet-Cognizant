﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FourSeasonsLib
{
    public class SeasonAdapter
    {
        public string GetSeason(string month) 
        {
            string text = month.ToLower();
            string result = "";
            if (text.Equals("february") || text.Equals("march")) result = "Spring";
            else if (text.Equals("april") || text.Equals("may") || text.Equals("june")) result = "Summer";
            else if (text.Equals("july") || text.Equals("august") || text.Equals("september")) result = "Monsoon";
            else if (text.Equals("september") || text.Equals("october") || text.Equals("november")) result = "Autumn";
            else if (text.Equals("december") || text.Equals("january")) result = "Winter";
            return result;
        }
    }
}
