using NUnit.Framework;
using FourSeasonsLib;

namespace ClassLib_Project.Tests
{
    public class SUT_Tests
    {
        [TestCase("February", "Spring")]
        [TestCase("April", "Summer")]
        [TestCase("July", "Monsoon")]
        [TestCase("November", "Autumn")]
        [TestCase("December", "Winter")]
        public void UnitUnderTest_Scenario_ExpectedOutcome(string month, string expected)
        {
            var s = new SeasonAdapter();
            string result = s.GetSeason(month);
            Assert.That(expected, Is.EqualTo(result));
        }
    }
}