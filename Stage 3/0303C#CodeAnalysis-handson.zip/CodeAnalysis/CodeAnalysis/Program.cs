﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeAnalysis
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "A", "B", "C", "D", "E", "F" };
            var namesOfB = names.Where(n => n.StartsWith("A"));

            Console.WriteLine("Enter n values to print");
            int num = int.Parse(Console.ReadLine());
            int i = 0;
            while (i < num)
            {
                Console.WriteLine(i);
                i++;
            }

            try
            {
                int a = int.Parse(Console.ReadLine());
                int b = int.Parse(Console.ReadLine());
                int c = a / b;
            }
            catch(Exception e)
            {

            }
        }
    }
}
