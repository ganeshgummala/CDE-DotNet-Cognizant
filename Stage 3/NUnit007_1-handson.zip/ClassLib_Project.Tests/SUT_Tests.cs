﻿using NUnit.Framework;
using System;
using UtilLib;

namespace ClassLib_Project.Tests
{
    [TestFixture]
    public class SUT_Tests
    {
        [Test]
        public void UnitUnderTest_Scenario_ExpectedOutcome1()
        {
            UrlHostNameParser obj = new UrlHostNameParser();
            string result = obj.ParseHostName("http://www.example.com/index.html");
            string expected = "www.example.com";
            Assert.That(expected, Is.EqualTo(result));
        }
        [Test]
        public void UnitUnderTest_Scenario_ExpectedOutcome2()
        {
            UrlHostNameParser obj = new UrlHostNameParser();
            string result = obj.ParseHostName("https://www.example.com/index.html");
            string expected = "www.example.com";
            Assert.That(expected, Is.EqualTo(result));
        }
    }
}
