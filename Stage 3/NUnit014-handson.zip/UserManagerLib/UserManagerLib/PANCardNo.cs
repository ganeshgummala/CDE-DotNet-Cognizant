﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserManagerLib
{
    public class PANCardNo
    {
        public int IsValid(string card) 
        {
            int flag = 0;
            if (card.Equals("") || card.Equals(null)) throw new NullReferenceException(nameof(card));
            else if (card.Length != 10) throw new FormatException(nameof(card));
            else flag = 1;
            return flag;
        }
    }
}
