using NUnit.Framework;
using UserManagerLib;
using System;

namespace ClassLib_Project.Tests
{
    public class SUT_Tests
    {
       
        [TestCase(null)]
        public void UnitUnderTest_Scenario_ExpectedOutcomeNullRef(string str)
        {
            var obj = new PANCardNo();
            int res = 0;
            Assert.Throws<NullReferenceException>(() => res = obj.IsValid(str));
        }

        [TestCase("ABCDE12345")]
        public void UnitUnderTest_Scenario_ExpectedOutcome1(string str)
        {
            var obj = new PANCardNo();
            int res = obj.IsValid(str);
            Assert.That(1, Is.EqualTo(res));
        }

        [TestCase("AS12121212")]
        public void UnitUnderTest_Scenario_ExpectedOutcome2(string str)
        {
            var obj = new PANCardNo();
            int res = obj.IsValid(str);
            Assert.That(1, Is.EqualTo(res));
        }

        [TestCase("AKSIW56")]
        public void UnitUnderTest_Scenario_ExpectedOutcomeFormatException(string str)
        {
            var obj = new PANCardNo();
            int res = 0;
            Assert.Throws<FormatException>(() => res = obj.IsValid(str));
        }
    }
}