﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConverterLib
{
    public class Converter : IDollarToEuroExchangeRateFeed
    {
        public double USDToEuro(double usd) 
        {
            double euro = 0.87 * usd;
            return euro;
        }
    }
}
