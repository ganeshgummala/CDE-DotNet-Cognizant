using NUnit.Framework;
using ConverterLib;
using Xunit;

namespace ClassLib_Project.Tests
{
    public class SUT_Tests
    {
        [Fact]
        [TestCase(2, 1.74)]
        public void UnitUnderTest_Scenario_ExpectedOutcome(double usd, double expected)
        {
            var obj = new Converter();
            double euro = obj.USDToEuro(usd);
            Assert.That(expected, Is.EqualTo(euro));
        }
    }
}